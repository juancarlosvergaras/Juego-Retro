(function(root){
 'use strict';
 const common=typeof module!=='undefined'&&module.exports;
 const apiOf=(name,file)=>common?require(file):root[name];
 const label=form=>form==='zombie'?'Zombi':form==='wolf'?'Lobo':'Soldado';
 function forms(p,won){return ['soldier',...(won||p.zombieUnlocked?['wolf']:[]),...(p.zombieUnlocked?['zombie']:[])];}
 function change(e,p,target){
  const list=forms(p,e.won),from=p.form||'soldier';target=target||list[(list.indexOf(from)+1)%list.length];
  if(e.dead||p.transform>0||p.formCooldown>0||p.burrow||p.rope||p.ladder||target===from||!list.includes(target))return false;
  p.transformFrom=from;p.form=target;p.h=target==='wolf'?64:target==='zombie'?68:46;p.transform=1.2;p.formCooldown=10;
  p.jetpack=false;p.claw=0;p.kick=0;p.slide=0;p.ram=null;p.wolfAttack=null;p.wolfQueued=null;p.vx=0;e.weaponAction=null;e.cooldown=1.2;
  return true;
 }
 function tick(p,dt){p.formCooldown=Math.max(0,(p.formCooldown||0)-dt);p.zombiePose=Math.max(0,(p.zombiePose||0)-dt);p.emerging=Math.max(0,(p.emerging||0)-dt);}
 function step(p,input,dt,platforms,world,surfaceY){
  if(p.form!=='zombie'){p.burrow=null;p.burrowLatch=false;return null;}
  if(!input.down)p.burrowLatch=false;
  const support=p.ground||platforms.find(s=>s.kind==='ground'&&p.x>=s.x&&p.x<=s.x+s.w&&Math.abs(surfaceY(s,p.x)-p.y)<2);
  if(!p.burrow&&input.down&&!input.fire&&!input.kick&&!input.jumpPressed&&!p.burrowLatch&&p.grounded&&support?.kind==='ground'&&!p.transform&&!p.hurt&&!p.rope&&!p.ladder){p.burrow={age:0,ground:support};p.burrowLatch=true;p.jetpack=false;p.slide=0;}
  if(!p.burrow){p.zombieCrouch=!!input.down&&p.grounded;return null;}
  const b=p.burrow;b.age+=dt;p.anim+=dt;p.vx=((input.right?1:0)-(input.left?1:0))*(input.run?260:180)*(p.speedBonus||1);if(p.vx)p.facing=Math.sign(p.vx);
  p.x=Math.max(Math.max(p.w/2,b.ground.x+p.w/2),Math.min(Math.min(world.width-p.w/2,b.ground.x+b.ground.w-p.w/2),p.x+p.vx*dt));
  p.y=surfaceY(b.ground,p.x);p.vy=0;p.grounded=true;p.ground=b.ground;p.jumps=0;p.fallDamage=0;p.fallPeak=p.y;
  if(b.age>=3){p.burrow=null;p.emerging=.35;}
  return{crouching:true,underground:!!p.burrow};
 }
 function targets(e){return [...(e.enemies||[]),...[e.boss,e.finalBoss,e.tank,e.king].filter(n=>n&&n.hp>0&&(n.active||n===e.tank))].filter(n=>n.hp>0&&!(n.kind==='king'&&['descend','crack','roar','death'].includes(n.phase)));}
 function damage(e,n,amount){
  if(n===e.tank)return apiOf('ArcadeCityTank','./city-tank').damage(n,amount);
  if(n===e.finalBoss)return apiOf('ArcadeFinalBoss','./final-boss').damage(n,amount);
  if(n===e.boss){n.hp=Math.max(0,n.hp-amount);n.hit=.18;return;}
  return apiOf('ArcadeEnemies','./enemies').damage(n,amount);
 }
 function combat(e,p,input,dt,platforms){
  const E=apiOf('ArcadeEncounter','./encounter');
  e.zombieEffects=(e.zombieEffects||[]).filter(f=>(f.life-=dt)>0);
  for(const n of targets(e))if(n.sticky>0){const active=Math.min(dt,n.sticky);n.sticky=Math.max(0,n.sticky-dt);n.stickyTick=(n.stickyTick||0)+active;while(n.stickyTick>=.5-1e-9){n.stickyTick=Math.max(0,n.stickyTick-.5);damage(e,n,.3);}}
  const blobs=e.playerPlasma||(e.playerPlasma=[]);
  for(const b of blobs){b.life-=dt;b.vy+=130*dt;const dx=b.vx*dt,dy=b.vy*dt;let first=1,target=null,blocked=false;
   for(const s of platforms){const t=E.segmentHit(b.x,b.y,dx,dy,{x:s.x,y:s.y,w:s.w,h:s.thickness||12,terrain:s.terrain});if(t!==null&&t<=first){first=t;blocked=true;}}
   for(const n of targets(e)){const t=E.segmentHit(b.x,b.y,dx,dy,{x:n.x-(n.w||28)/2,y:n.y-(n.h||64),w:n.w||28,h:n.h||64});if(t!==null&&t<first){first=t;target=n;blocked=true;}}
   b.x+=dx*first;b.y+=dy*first;
   if(blocked){b.life=0;e.zombieEffects.push({kind:'splash',x:b.x,y:b.y,life:.4});if(target){damage(e,target,1*(p.damageBonus||1));if(target.hp>0)target.sticky=4;}}
  }e.playerPlasma=blobs.filter(b=>b.life>0);
  p.plasmaWait=Math.max(0,(p.plasmaWait||0)-dt);p.rayWait=Math.max(0,(p.rayWait||0)-dt);
  if(p.form!=='zombie'||p.burrow||p.transform>0||p.hurt>0||e.dead)return;
  const aim=p.aim||{x:p.facing||1,y:0},x=p.x+(p.facing||1)*24,y=p.y-(p.zombieCrouch?25:38);
  if(input.kick&&p.plasmaWait<=0){p.plasmaWait=.85;p.zombiePose=.45;p.zombieAction='plasma';e.playerPlasma.push({x,y,vx:aim.x*360,vy:aim.y*360-20,life:1.6});e.flash=.08;}
  else if(input.fire&&p.rayWait<=0){p.rayWait=.28/(p.rateBonus||1);p.zombiePose=.28;p.zombieAction='ray';let distance=440;
   for(const s of platforms){const t=E.segmentHit(x,y,aim.x*distance,aim.y*distance,{x:s.x,y:s.y,w:s.w,h:s.thickness||12,terrain:s.terrain});if(t!==null)distance*=t;}
   const hits=targets(e).map(n=>({n,t:E.segmentHit(x,y,aim.x*distance,aim.y*distance,{x:n.x-(n.w||28)/2,y:n.y-(n.h||64),w:n.w||28,h:n.h||64})})).filter(a=>a.t!==null).sort((a,b)=>a.t-b.t);
   if(hits.length){damage(e,hits[0].n,1.2*(p.damageBonus||1));distance*=hits[0].t;}
   e.zombieEffects.push({kind:'ray',x,y,tx:x+aim.x*distance,ty:y+aim.y*distance,life:.16});e.flash=.08;
  }
 }
 let atlas=null,extra=null;
 function prepare(image,rowCount,bands,cuts={}){
  const c=document.createElement('canvas');c.width=image.width;c.height=image.height;const ctx=c.getContext('2d');ctx.drawImage(image,0,0);const d=ctx.getImageData(0,0,c.width,c.height).data,rows=[];
  for(let row=0;row<rowCount;row++){const frames=[];for(let col=0;col<6;col++){const xs=cuts.x?.[row],x0=xs?xs[col]:Math.round(col*c.width/6),x1=xs?xs[col+1]:Math.round((col+1)*c.width/6),y0=Math.round((cuts.y?.[row]?.[col]??bands[row])*c.height/bands.at(-1)),y1=Math.round((cuts.y?.[row+1]?.[col]??bands[row+1])*c.height/bands.at(-1));let l=x1,r=x0,t=y1,b=y0;
    for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++)if(d[(y*c.width+x)*4+3]>190){l=Math.min(l,x);r=Math.max(r,x);t=Math.min(t,y);b=Math.max(b,y);}frames.push({x:l,y:t,w:r-l+1,h:b-t+1,pivot:(col+.5)*c.width/6,base:b+1});}rows.push(frames);}
  return {image,rows,scale:68/rows[0][0].h};
 }
 function setSheet(image){atlas=prepare(image,6,[0,226,440,643,855,1080,1254],{x:{3:[0,209,418,627,836,1060,1254],4:[0,209,418,627,836,1060,1254]}});return atlas;}
 function setExtra(image){extra=prepare(image,4,[0,280,530,775,1024],{x:{0:[0,256,506,748,995,1248,1536],1:[0,256,512,750,1024,1280,1536]},y:{3:[775,775,747,740,775,775]}});return extra;}
 function icon(){const f=atlas?.rows[0][0];return f?{image:atlas.image,frame:[f.x,f.y,f.w,f.h]}:null;}
 function pose(p){if(p.kind==='stormZombie'&&p.hp<=0)return{extra:true,row:0,frame:Math.min(5,Math.floor((1-p.death/1.5)*6))};if(p.transform>0)return{extra:true,row:3,frame:Math.min(5,Math.floor((1-p.transform/1.2)*6))};if(p.phase==='ring'&&p.hp>0)return{extra:true,row:1,frame:Math.min(5,Math.floor(p.age/1.55*6))};if(p.kind==='stormZombie'&&p.phase!=='idle')return{row:p.phase==='plasma'?4:3,frame:Math.min(5,Math.floor(p.age/1.55*6))};if(!p.grounded&&!p.burrow&&!p.rope&&!p.ladder)return{extra:true,row:2,frame:p.vy< -120?1:p.vy<0?2:p.vy<120?3:4};if(p.burrow)return{row:5,frame:p.burrow.age<.2?1:p.burrow.age<.4?2:p.burrow.age<.6?3:4};if(p.emerging>0)return{row:5,frame:5};if(p.zombieCrouch)return{row:5,frame:0};if(p.zombiePose>0)return{row:p.zombieAction==='plasma'?4:3,frame:Math.min(5,Math.floor((1-p.zombiePose/(p.zombieAction==='plasma'?.45:.28))*6))};return{row:Math.abs(p.vx)>170?2:Math.abs(p.vx)>8?1:0,frame:Math.floor((p.anim||0)*(Math.abs(p.vx)>8?10:4))%6};}
 function draw(c,p,scale=1){if(!atlas)return;const q=pose(p),sheet=q.extra&&extra?extra:atlas,f=sheet.rows[q.row][q.frame],s=sheet.scale*scale;c.save();c.translate(Math.round(p.x),Math.round(p.y));c.scale(p.facing||1,1);if(p.hit>0)c.filter='brightness(1.6)';c.drawImage(sheet.image,f.x,f.y,f.w,f.h,(f.x-f.pivot)*s,-f.h*s,f.w*s,f.h*s);c.restore();}
 function drawPlayer(c,p){if(p.form!=='zombie'&&!(p.transform>0&&p.transformFrom==='zombie'))return false;
  c.save();if(p.transform>0)c.globalAlpha=.4+.6*Math.sin((1-p.transform/1.2)*Math.PI);draw(c,p);if(p.transform>0){c.strokeStyle='#8cf2bd';c.lineWidth=3;c.beginPath();c.ellipse(p.x,p.y-30,22+Math.sin(p.transform*10)*4,45,0,0,Math.PI*2);c.stroke();}c.restore();return true;}
 function drawEffects(c,e){c.save();for(const n of targets(e))if(n.sticky>0){c.fillStyle='#6fcc5370';c.fillRect(n.x-(n.w||28)/2,n.y-8,n.w||28,5);for(let i=0;i<4;i++)c.fillRect(n.x-12+i*8,n.y-15-(i%2)*9,3,10);}
  for(const b of e.playerPlasma||[]){c.fillStyle='#244d2e';c.beginPath();c.arc(b.x,b.y,7,0,Math.PI*2);c.fill();c.fillStyle='#9aee4d';c.fillRect(b.x-3,b.y-3,6,6);}
  for(const f of e.zombieEffects||[]){c.globalAlpha=Math.min(1,f.life*8);if(f.kind==='ray'){c.strokeStyle='#42d1ed';c.lineWidth=5;c.beginPath();c.moveTo(f.x,f.y);for(let i=1;i<=10;i++){const t=i/10;c.lineTo(f.x+(f.tx-f.x)*t+(i%2?3:-3),f.y+(f.ty-f.y)*t+(i%2?-5:5));}c.stroke();c.strokeStyle='#e4feff';c.lineWidth=2;c.stroke();}else{c.fillStyle='#9bd946';for(let i=0;i<8;i++)c.fillRect(f.x+Math.cos(i)*22*(1-f.life),f.y+Math.sin(i)*22*(1-f.life),4,4);}}c.restore();}
 const api={forms,label,change,tick,step,combat,targets,setSheet,setExtra,icon,pose,draw,drawPlayer,drawEffects};if(common)module.exports=api;else root.ArcadeZombieForm=api;
})(typeof window!=='undefined'?window:globalThis);
